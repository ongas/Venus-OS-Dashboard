var langEn = {
  tab1Render: {
    theme_choice: "Select card theme:",
    light: "Light",
    dark: "Dark",
    auto: "Auto",
    devices_per_column: "Number of \"Devices\" per column:",
    font_size_zones: "Font size in \"Devices\" zones:",
    in_header: "in header",
    in_devices: "in devices",
    in_footer: "in footer",
    font_size: "Font size"
  },
  subtabRender: {
    header_title: "Header configuration",
    icon_choice: "Icon picker",
    name_choice: "Device name",
    sensor_title: "Main sensor configuration",
    entity_choice: "Entity picker",
    entity2_choice: "Secondary entity picker",
    enable_graph: "Enable graphic",
    enable_gauge: "Enable gauge",
    gauge_max: "Gauge max value",
    enable_side_gauge: "Enable side gauge",
    side_gauge_entity: "Side gauge entity",
    side_gauge_max: "Side gauge max value",
    header_footer_title: "Header and footer sensors configuration",
    entity_header: "Select header entity",
    entity_footer: "Select footer entity",
    entity2_footer: "Select 2nd footer entity",
    entity3_footer: "Select 3th header entity",
    anchor_title: "Add anchor",
    left_qtyBox: "Left",
    top_qtyBox: "Top",
    bottom_qtyBox: "Bottom",
    right_qtyBox: "Right",
    add_links: "Add links",
    add_link: "Add link"
  },
  addLink: {
    start: "Start",
    end: "End",
    entity_picker: "Select entity",
    reverse: "reverse"
  }
};

export { langEn as default };
